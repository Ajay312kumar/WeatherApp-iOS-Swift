//
//  DescriptionCollectionViewCell.swift
//  Weather-App-iOS
//
//  Created by iPHTech 29 on 06/06/23.
//

import UIKit

class DescriptionCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var forecastView: UIView!
    @IBOutlet weak var currentDateLbl: UILabel!
    
    
}
